#include <iostream>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <opencv2/opencv.hpp>  // OpenCV 库
#include <thread>  // 包含多线程库
#include "serial_comm.h"

#define SERVER_IP "192.168.1.2"   // 服务器 IP 地址
#define BUFFER_SIZE 1024          // 缓冲区大小

class Video_TcpClient {
public:
    Video_TcpClient(const std::string& serverIp, int serverPort)
        : serverIp(serverIp), serverPort(serverPort), sockfd(-1) {}

    ~Video_TcpClient() {
        if (sockfd != -1) {
            close(sockfd);
        }
    }

    bool connectToServer() {
        // 创建套接字
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd == -1) {
            std::cerr << "创建套接字失败" << std::endl;
            return false;
        }

        // 设置服务器地址
        struct sockaddr_in serverAddr;
        memset(&serverAddr, 0, sizeof(serverAddr));
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(serverPort);
        serverAddr.sin_addr.s_addr = inet_addr(serverIp.c_str());

        // 连接到服务器
        if (connect(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
            std::cerr << "Video连接服务器失败" << std::endl;
            return false;
        }

        std::cout << "成功连接到服务器 " << serverIp << ":" << serverPort << std::endl;
        return true;
    }

    void sendVideoStream() {
        // 使用 OpenCV 打开视频流
        cv::VideoCapture cap("/dev/video9");  // 视频设备路径
        if (!cap.isOpened()) {
            std::cerr << "打开视频设备失败" << std::endl;
            return;
        }

        cap.set(cv::CAP_PROP_FRAME_WIDTH, 640);
        cap.set(cv::CAP_PROP_FRAME_HEIGHT, 480);
        /*
        1280×720 (30 FPS)
        480×720 (30 FPS)
        640×480 (30 FPS)
        320×480 (30 FPS)
        480×640 (30 FPS)
        800×480 (30 FPS)
        */

        cv::Mat frame, resized;
        while (true) {
            cap >> frame;  // 读取一帧
            cv::resize(frame, resized, cv::Size(640, 480)); 
            if (resized.empty()) {
                break;  // 视频流结束
            }
            // std::cout << "实际分辨率: " 
            //       << cap.get(cv::CAP_PROP_FRAME_WIDTH) << "x" 
            //       << cap.get(cv::CAP_PROP_FRAME_HEIGHT) << std::endl;

            // 编码图像为JPEG格式
            std::vector<uchar> buffer;
            cv::imencode(".jpg", resized, buffer);

            // 获取图像大小
            uint64_t imageSize = buffer.size();

            // 发送图像大小
            if (send(sockfd, &imageSize, sizeof(imageSize), 0) == -1) {
                std::cerr << "发送图像大小失败" << std::endl;
                break;
            }

            // 发送图像数据
            if (send(sockfd, buffer.data(), buffer.size(), 0) == -1) {
                std::cerr << "发送图像数据失败" << std::endl;
                break;
            }

            //std::cout << "发送一帧图像，大小：" << imageSize << " 字节" << std::endl;

            // 可以加入延时，防止发送过快
            usleep(10000);  // 暂停10毫秒
        }
    }

private:
    std::string serverIp;
    int serverPort;
    int sockfd;
};

class Message_TcpClient {
public:
    Message_TcpClient(const std::string& serverIp, int serverPort)
        : serverIp(serverIp), serverPort(serverPort), sockfd(-1) {}

    ~Message_TcpClient() {
        if (sockfd != -1) {
            close(sockfd);
        }
    }

    bool connectToServer() {
        // 创建套接字
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd == -1) {
            std::cerr << "创建套接字失败" << std::endl;
            return false;
        }

        // 设置服务器地址
        struct sockaddr_in serverAddr;
        memset(&serverAddr, 0, sizeof(serverAddr));
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(serverPort);
        serverAddr.sin_addr.s_addr = inet_addr(serverIp.c_str());

        // 连接到服务器
        if (connect(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
            std::cerr << "Message连接服务器失败" << std::endl;
            return false;
        }

        std::cout << "成功连接到服务器 " << serverIp << ":" << serverPort << std::endl;
        return true;
    }

    void sendMessage(const std::string& message) {
        if (sockfd != -1) {
            send(sockfd, message.c_str(), message.size(), 0);
            std::cout << "发送消息: " << message << std::endl;
        }
    }

    std::string receiveMessage() {
        char buffer[BUFFER_SIZE] = {0};
        int bytesRead = recv(sockfd, buffer, sizeof(buffer) - 1, 0);
        if (bytesRead > 0) {
            buffer[bytesRead] = '\0';  // 确保字符串以 '\0' 结束
            return std::string(buffer);
        } else if (bytesRead == 0) {
            std::cerr << "连接关闭" << std::endl;
        } else {
            std::cerr << "接收数据失败" << std::endl;
        }
        return "";
    }

private:
    std::string serverIp;
    int serverPort;
    int sockfd;
};

int main() {
    // 创建消息客户端和视频客户端对象
    Video_TcpClient video_client(SERVER_IP, 12345);  // 视频流
    Message_TcpClient message_client(SERVER_IP, 12346);  // 按键数据

    // 创建串口通信对象
    SerialComm serialComm;
    serialComm.port = SERIAL_PORT;
    serialComm.baud_rate = BAUD_RATE;
    serialComm.timeout = TIMEOUT;

    // 尝试连接到服务器
    if (!video_client.connectToServer() || !message_client.connectToServer()) {
        return -1;
    }

    // 打开串口
    if (open_serial(&serialComm) != 0) {
        return -1;  // 串口打开失败，退出程序
    }

    // 启动两个线程，一个负责发送视频流，另一个接收数据
    std::thread videoThread([&video_client]() {
        video_client.sendVideoStream();
    });

    std::thread messageThread([&message_client, &serialComm]() {
        while (true) {
            std::string response = message_client.receiveMessage();
            
            if (!response.empty()) {
                // 调试：打印接收到的消息以及其长度
                //std::cout << "接收到的原始消息: '" << response << "'" << std::endl;
                //std::cout << "消息长度: " << response.length() << std::endl;
                
                // 移除字符串开头和结尾的空格及换行符
                response.erase(0, response.find_first_not_of("\n\r\t "));
                response.erase(response.find_last_not_of("\n\r\t ") + 1);
                if (response.length() > 3) {
                    response = response.substr(0, 3);  // 只保留第一个字符
                }
                // 再次打印消息，确认已经去掉了空格和换行符
                //std::cout << "处理后的第一个字符: '" << response << "'" << std::endl;
                response.erase(std::remove_if(response.begin(), response.end(), 
                [](char c) { return c == '\r' || c == '\n'; }), response.end());

                char serial_data = '\0';  // 默认值为 null 字符
        
                // 比较字符串并映射到相应的字符
                if (response == "17") {
                    serial_data = 'w';  // 键值 "17" 映射为字母 'w'
                    std::cout << "字符串w" << std::endl;
                } else if (response == "31") {
                    serial_data = 's';  // 键值 "31" 映射为字母 's'
                    std::cout << "字符串s" << std::endl;
                } else if (response == "30") {
                    serial_data = 'a';  // 键值 "30" 映射为字母 'a'
                    std::cout << "字符串a" << std::endl;
                } else if (response == "32") {
                    serial_data = 'd';  // 键值 "32" 映射为字母 'd'
                    std::cout << "字符串d" << std::endl;
                }
                else if (response == "16") {
                    serial_data = 'q';  // 键值 "32" 映射为字母 'd'
                    std::cout << "字符串q" << std::endl;
                }
                else if (response == "18") {
                    serial_data = 'e';  // 键值 "32" 映射为字母 'd'
                    std::cout << "字符串e" << std::endl;
                }
                else if (response == "33") {
                    serial_data = 'f';  // 键值 "32" 映射为字母 'd'
                    std::cout << "字符串f" << std::endl;
                }
                else
                {
                    //停止
                    serial_data = 'z';
                }
        
                // 如果 serial_data 已经被正确赋值，发送数据
                if (serial_data != '\0') {
                    // 直接传递字符，而不是字符指针
                    send_data(&serialComm, serial_data);    // 发送字符
                    std::cout << "串口发送: " << serial_data << std::endl;
                } else {
                    std::cout << "未匹配到有效的键值，无法发送数据。" << std::endl;
                }
            }
            
            usleep(1000);  // 每1毫秒接收一次
        }
    });
    
    
    // 等待线程结束
    videoThread.join();
    messageThread.join();

    // 关闭串口
    close_serial(&serialComm);

    return 0;
}
