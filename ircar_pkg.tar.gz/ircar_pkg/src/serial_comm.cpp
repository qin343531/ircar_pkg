#include "serial_comm.h"

//映射宏值
int get_baud_rate(speed_t baud_rate)
{
    switch (baud_rate) {
        case B9600: return 9600;
        case B19200: return 19200;
        case B38400: return 38400;
        case B57600: return 57600;
        case B115200: return 115200;
        case B230400: return 230400;
        default: return -1; // 未知波特率
    }
}


// 打开串口
int open_serial(SerialComm *serial) 
{
    serial->fd = open(serial->port, O_RDWR | O_NOCTTY | O_NDELAY);
    if (serial->fd == -1) {
        perror("无法打开串口");
        return -1;
    }

    struct termios options;
    tcgetattr(serial->fd, &options);

    // 设置波特率
    if (cfsetispeed(&options, BAUD_RATE) == -1) {
        perror("设置输入波特率失败");
        close(serial->fd);
        return -1;
    }
    if (cfsetospeed(&options, BAUD_RATE) == -1) {
        perror("设置输出波特率失败");
        close(serial->fd);
        return -1;
    }

    // 设置其他串口选项（数据位、停止位等）
    options.c_cflag &= ~PARENB;  // 无校验位
    options.c_cflag &= ~CSTOPB;  // 1位停止位
    options.c_cflag &= ~CSIZE;
    options.c_cflag |= CS8;      // 8位数据位

    options.c_cflag |= (CLOCAL | CREAD);  // 允许接受数据
    options.c_iflag &= ~(IXON | IXOFF | IXANY);  // 禁用流控制
    options.c_iflag &= ~ICANON;  // 禁用规范模式
    options.c_iflag &= ~ECHO;    // 禁用回显
    options.c_iflag &= ~ECHOE;   // 禁用回显（输入时不显示字符）
    options.c_iflag &= ~ISIG;    // 禁用信号

    tcsetattr(serial->fd, TCSANOW, &options);  // 应用设置

    printf("串口 %s 已打开，波特率：%d\n", serial->port, get_baud_rate(BAUD_RATE));
    return 0;
}

// 向串口发送数据，修改为发送单个字符
int send_data(SerialComm *serial, char data) 
{
    if (serial->fd == -1) 
    {
        std::cout << "串口未打开" << std::endl;
        return -1;
    }
    if (write(serial->fd, &data, 1) != 1) 
    {
        perror("写入串口失败");
        return -1;
    }
    return 0;
}


// 关闭串口
void close_serial(SerialComm *serial) 
{
    if (serial->fd != -1) {
        close(serial->fd);
        printf("串口 %s 已关闭\n", serial->port);
    }
}
