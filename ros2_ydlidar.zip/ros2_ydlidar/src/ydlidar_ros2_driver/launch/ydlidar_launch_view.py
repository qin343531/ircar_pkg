#!/usr/bin/python3

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
import os

def generate_launch_description():
    rviz_config_dir = os.path.join(
        get_package_share_directory('ydlidar_ros2_driver'),
        'config',
        'ydlidar.rviz')

    return LaunchDescription([
        Node(
            package='ydlidar_ros2_driver',
            executable='ydlidar_ros2_driver_node',
            output='screen',
            parameters=[{
                'port': '/dev/ttyUSB0',
                'frame_id': 'laser_frame',
                'baudrate': 115200,
                'lidar_type': 1,
                'sample_rate': 3,
                'fixed_resolution': True,
                'isSingleChannel': True,
                'frequency': 10.0
            }]
        ),
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            arguments=['0', '0', '0.02', '0', '0', '0', '1', 'base_link', 'laser_frame']
        ),
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config_dir]
        )
    ])
