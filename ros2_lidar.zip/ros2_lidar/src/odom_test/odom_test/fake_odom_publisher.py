#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist, Pose, Point, Quaternion
from std_msgs.msg import Header
import math
import time

class FakeOdomPublisher(Node):
    def __init__(self):
        super().__init__('fake_odom_publisher')
        self.publisher_ = self.create_publisher(Odometry, 'odom', 10)
        self.timer_ = self.create_timer(0.1, self.publish_odom)
        self.start_time = self.get_clock().now().seconds_nanoseconds()[0]

    def publish_odom(self):
        now = self.get_clock().now()
        timestamp = now.to_msg()

        elapsed = now.seconds_nanoseconds()[0] - self.start_time
        x = 0.1 * elapsed  # 模拟 x 方向匀速运动
        y = 0.0
        theta = 0.0

        odom_msg = Odometry()
        odom_msg.header = Header()
        odom_msg.header.stamp = timestamp
        odom_msg.header.frame_id = 'odom'
        odom_msg.child_frame_id = 'base_link'

        odom_msg.pose.pose.position = Point(x=x, y=y, z=0.0)
        odom_msg.pose.pose.orientation = Quaternion(x=0.0, y=0.0, z=0.0, w=1.0)

        odom_msg.twist.twist.linear.x = 0.1
        odom_msg.twist.twist.angular.z = 0.0

        self.publisher_.publish(odom_msg)
        self.get_logger().info(f"Published fake odometry: x={x:.2f}")

def main(args=None):
    rclpy.init(args=args)
    node = FakeOdomPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

