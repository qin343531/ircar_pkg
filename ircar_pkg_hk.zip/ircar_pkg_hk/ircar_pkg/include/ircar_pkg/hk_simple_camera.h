#ifndef HK_SIMPLE_CAMERA_H
#define HK_SIMPLE_CAMERA_H

#include "hk_camera.h"

namespace hk {

class SimpleCamera {
public:
	SimpleCamera();
    ~SimpleCamera();

    void startCapture();
    void stopCapture();
    std::vector<uint16_t> getImage(); // 获取图像
    void focus_setup(int step);
private:
	DeviceFunction deviceFunction;
    GetVideoStream getVideoStream;
};

}
#endif