#ifndef HK_CAMERA_H
#define HK_CAMERA_H

#include <string>
#include <thread>
#include <atomic>
#include <mutex>
#include <queue>
#include <vector>
#include <fstream>
#include <condition_variable>
#include "HCNetSDK.h"

namespace hk {

typedef struct
{
	short year;             /*APP->DSP 年*/
	short month;            /*APP->DSP 月*/
	short dayOfWeek;        /*APP->DSP 0:星期日-6:星期六*/
	short day;              /*APP->DSP 日*/
	short hour;             /*APP->DSP 小时*/
	short minute;           /*APP->DSP 分钟*/
	short second;           /*APP->DSP 秒*/
	short milliSecond;      /*APP->DSP 毫秒*/
}DATE_TIME;

typedef struct
{
	UINT u32TmDataMode;      /* 0为4字节，1为2字节 */
	UINT u32TmScale;         /* 测温缩放比例 */
	UINT u32TmOffset;        /* 测温偏移量，当前固定为0 */
	LONG  byIsFreezedata;      /*是否是冻结数据，1:冻结，0:非冻结*/
}STREAM_FS_SUPPLE_INFO_TEMP;

typedef struct _STREAM_RT_DATA_INFO_S_
{
	UINT u32RTDataType; // 1-14bit裸数据; 2-全屏测温结果数据; 3-YUV数据
	UINT u32FrmNum;
	UINT u32StdStamp; //DSP相对时间戳
	DATE_TIME stTime; //绝对时间戳
	UINT u32Width;
	UINT u32Height;
	UINT u32Len;
	UINT u32Fps;
	UINT u32Chan;
}STREAM_RT_DATA_INFO_S;

typedef struct _STREAM_FARME_INFO_TEMP_S_
{
	UINT u32MagicNo;        //0x70827773  "FRMI"的ascll码
	UINT u32HeaderSize;     //结构体长度
	UINT u32StreamType;     //数据类型： h264/h265, JPEG, Audio, MetaData, RTData: 参见 STREAM_TYPE_E
	UINT u32StreamLen;      //数据长度
	STREAM_RT_DATA_INFO_S stRTDataInfo;
	STREAM_FS_SUPPLE_INFO_TEMP stFsSuppleInfo;
	UINT res[12];
	UINT u32CrcVal; //结构体校验码 对结构体前面数据进行校验
}STREAM_FARME_INFO_TEMP;

// 摄像头上报数据，回调处理函数
void CALLBACK g_RealDataCallBack_V30(LONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, void* dwUser);

/**
 * @class DeviceFunction
 * @brief 线程类：负责海康热成像仪网络连接和登录、取流、聚焦
 */
class DeviceFunction {
public:
    NET_DVR_USER_LOGIN_INFO loginInfo; // 登录信息
    NET_DVR_DEVICEINFO_V40 deviceInfo; // 设备信息
    DeviceFunction();
    ~DeviceFunction();
    // 启动登录线程
    void start_check_login_status_thread();
    // 停止登录线程
    void stop_check_login_status_thread();
    // 启动获取裸数据线程
    void start_get_raw_data_thread();
    // 停止获取裸数据线程
    void stop_get_raw_data_thread();
    // 等待线程结束
    void join();
    bool isConnect(const std::string& ipAddress, int port, int timeoutSec);
	void focus_setup(int step);

    // 删除拷贝构造函数和赋值运算符
    DeviceFunction(const DeviceFunction&) = delete;
    DeviceFunction& operator=(const DeviceFunction&) = delete;

    // 添加移动构造函数和移动赋值运算符
    DeviceFunction(DeviceFunction&&) = default;
    DeviceFunction& operator=(DeviceFunction&&) = default;

private:
    std::atomic<bool> running_;     // 控制线程运行的标志
    std::thread thread_;            // 线程对象
    LONG lUserID;                   // 用户ID句柄
    LONG lRealPlayHandle;
    // 线程函数
    void check_login_status_thread();
};

class GetVideoStream {
public:
	GetVideoStream();
	~GetVideoStream();
	std::pair<int, int> findMagicBytesPositions(const std::vector<uint8_t>& raw_data);
	std::vector<uint8_t> processRawData(std::vector<uint8_t>& raw_data);
	std::queue<std::vector<uint16_t>> imageQueue;
	std::vector<uint16_t> newImage;
	std::vector<uint16_t> getImage();
	void start_get_video_stream_thread();
	void stop_get_video_stream_thread();
	// 等待线程结束
    void join();

    // 删除拷贝构造函数和赋值运算符
    GetVideoStream(const GetVideoStream&) = delete;
    GetVideoStream& operator=(const GetVideoStream&) = delete;

    // 添加移动构造函数和移动赋值运算符
    GetVideoStream(GetVideoStream&&) = default;
    GetVideoStream& operator=(GetVideoStream&&) = default;

private:
	std::mutex mtx_newImageQueue;
	const size_t maxQueueSize = 500; 
	std::atomic<bool> running_;		// 控制线程运行的标志
	std::thread thread_;			// 线程对象			
	void get_video_stream_thread();
};

} // namespace hk

#endif // COMMON_THREAD_H
