#ifndef HK_RTSP_H
#define HK_RTSP_H

#include <string>
#include <vector>
#include <queue>
#include <mutex>
#include <thread>
#include <opencv2/opencv.hpp>
#include "HCNetSDK.h"

namespace hk {

class RtspCamera {
public:
    RtspCamera();
    ~RtspCamera();

    // 添加流类型常量
    enum StreamType {
        MAIN_COLOR_STREAM = 0,    // 彩色主码流
        SUB_COLOR_STREAM = 1,     // 彩色子码流
        MAIN_H264_STREAM = 2,     // H264主码流
        SUB_H264_STREAM = 3,      // H264子码流
        MAIN_THERMAL_STREAM = 4,  // 热成像主码流
        SUB_THERMAL_STREAM = 5    // 热成像子码流
    };

    void startCapture();
    void stopCapture();
    cv::Mat getFrame();
    bool isConnect();  // 移除参数，使用类成员中的IP和端口
    std::string getRtspUrl(StreamType type = MAIN_COLOR_STREAM) const;  // 修改函数声明，添加参数

private:
    LONG m_userId;
    LONG m_realPlayHandle;
    bool m_isRunning;
    std::thread m_thread;
    std::mutex m_queueMutex;
    std::queue<cv::Mat> m_frameQueue;
    static const int MAX_QUEUE_SIZE = 10;
    std::string m_ipAddress;
    int m_port;
    cv::VideoCapture m_cap;  // 添加VideoCapture成员变量

    bool initializeCamera();
    void streamThread();
    void processFrame(BYTE *pBuffer, DWORD dwBufSize);
    static void CALLBACK streamCallback(LONG lPlayHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, void* pUser);
    const char* getRtspStreamType(int streamType) const;
};

} // namespace hk

#endif // HK_RTSP_H
