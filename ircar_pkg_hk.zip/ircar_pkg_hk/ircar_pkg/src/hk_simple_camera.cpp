#include "hk_simple_camera.h"

namespace hk {

SimpleCamera::SimpleCamera() 
    : deviceFunction(), getVideoStream() {
}

SimpleCamera::~SimpleCamera() {
    stopCapture();
}

void SimpleCamera::startCapture() {
    deviceFunction.start_check_login_status_thread();
    getVideoStream.start_get_video_stream_thread();
}

void SimpleCamera::stopCapture() {
    deviceFunction.stop_check_login_status_thread();
    getVideoStream.stop_get_video_stream_thread();
}

std::vector<uint16_t> SimpleCamera::getImage() { 
    return getVideoStream.getImage();
}

void SimpleCamera::focus_setup(int step) {
    deviceFunction.focus_setup(step);
}

}