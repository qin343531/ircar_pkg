#include "hk_simple_camera.h"
#include <iostream>
#include <opencv2/opencv.hpp>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <vector>
#include <cstring>

#define SERVER_IP "192.168.1.2"
#define SERVER_PORT 12345

// 发送灰度图像的函数
void sendVideoStream(int sockfd, hk::SimpleCamera& camera, bool& isSending) 
{
    while (isSending) 
    {
        auto raw_data = camera.getImage();
        if (raw_data.empty()) {
            continue;
        }

        // 将图像数据转换为 OpenCV Mat 格式
        cv::Mat src(288, 384, CV_16UC1, raw_data.data());
        cv::Mat image;
        cv::normalize(src, image, 0, 255, cv::NORM_MINMAX, CV_8UC1);

        // 编码为 JPEG 格式
        std::vector<uchar> buffer;
        std::vector<int> params = {cv::IMWRITE_JPEG_QUALITY, 90};
        if (!cv::imencode(".jpg", image, buffer, params)) {
            continue;
        }

        // 发送图像大小
        uint64_t imageSize = buffer.size();
        if (send(sockfd, &imageSize, sizeof(imageSize), 0) < 0) {
            break;
        }

        // 发送图像数据
        if (send(sockfd, buffer.data(), buffer.size(), 0) < 0) {
            break;
        }

        cv::waitKey(1);  // 控制帧率
    }
}

// 发送彩色图像的函数
void sendColorVideoStream(int sockfd, hk::SimpleCamera& camera, bool& isSending) 
{
    while (isSending) 
    {
        auto raw_data = camera.getImage();
        if (raw_data.empty()) {
            continue;
        }

        // 将图像数据转换为 OpenCV Mat 格式
        cv::Mat src(288, 384, CV_16UC1, raw_data.data());
        cv::Mat image;
        cv::normalize(src, image, 0, 255, cv::NORM_MINMAX, CV_8UC1);

        // 将灰度图像转换为彩色图像
        cv::Mat colorImage;
        cv::applyColorMap(image, colorImage, cv::COLORMAP_JET);

        // 编码为 JPEG 格式
        std::vector<uchar> buffer;
        std::vector<int> params = {cv::IMWRITE_JPEG_QUALITY, 90};
        if (!cv::imencode(".jpg", colorImage, buffer, params)) {
            continue;
        }

        // 发送图像大小
        uint64_t imageSize = buffer.size();
        if (send(sockfd, &imageSize, sizeof(imageSize), 0) < 0) {
            break;
        }

        // 发送图像数据
        if (send(sockfd, buffer.data(), buffer.size(), 0) < 0) {
            break;
        }

        cv::waitKey(1);  // 控制帧率
    }
}

int main() {
    // 初始化摄像头
    hk::SimpleCamera simpleCamera;
    simpleCamera.startCapture();

    // 创建 TCP 套接字
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        std::cerr << "Socket creation failed!" << std::endl;
        return -1;
    }

    // 配置服务器地址
    sockaddr_in serverAddr;
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    if (inet_pton(AF_INET, SERVER_IP, &serverAddr.sin_addr) <= 0) {
        std::cerr << "Invalid server IP address!" << std::endl;
        close(sock);
        return -1;
    }

    // 连接到服务器
    if (connect(sock, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        std::cerr << "Connection to server failed!" << std::endl;
        close(sock);
        return -1;
    }
    std::cout << "Connected to server: " << SERVER_IP << ":" << SERVER_PORT << std::endl;

    // 开始获取视频流并发送
    bool isSending = true;

    // 选择发送灰度图像或彩色图像
    // sendVideoStream(sock, simpleCamera, isSending); // 发送灰度图像
    sendColorVideoStream(sock, simpleCamera, isSending); // 发送彩色图像

    // 关闭摄像头和套接字
    simpleCamera.stopCapture();
    close(sock);
    return 0;
}