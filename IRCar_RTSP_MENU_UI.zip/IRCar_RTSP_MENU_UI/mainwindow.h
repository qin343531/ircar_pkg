#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpServer>
#include <QTcpSocket>
#include <QTextEdit>
#include <QLabel>
#include <QList>
#include "gamepadreader.h"
#include <QTimer>
#include <QDir>
#include <QDateTime>

#include "hk_rtsp.h"  // 替换原来的hk_camera.h
#include <iostream>
#include <opencv2/opencv.hpp>
#include <mutex>
#include "splashscreen.h"

namespace Ui {
    class MainWindow;  // 声明Ui::MainWindow类
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void newVideoClient();             // 新的视频客户端连接
    void newMessageClient();           // 新的按键数据客户端连接
    void readVideoData();              // 读取视频数据
    //void readMessageData();            // 读取按键数据
    void readKey();                    // 读取按键信息
    void on_IRButton_clicked();

    void on_gameboxButton_clicked();     // 开始/停止按键监控按钮点击

    void on_CamButton_clicked(); // 开始/停止接收按钮点击
    void updateImage(); //红外图像接收

    //void on_saveImageButton_clicked();
    //void on_recordButton_clicked();   //录制红外和可见光

    void on_recordCamButton_clicked();  //录制可见光

    void on_recordIRButton_clicked();   //录制红外

    void on_saveCamButton_clicked();    //保存可见光

    void on_saveIRButton_clicked();     //保存红外

private:
    void sendMessageToClients(const QByteArray &message);  // 发送消息到客户端
    QTcpSocket* getClientSocket();    // 获取按键数据客户端连接
    QString getLocalIpAddress();      // 获取本地 IP 地址
    void recordCamImage(const QString &timestamp); //录制可见光图像
    void recordIRImage(const QString &timestamp);
    void initializeServices();  // 添加新的初始化函数
    Ui::MainWindow *ui;               // Ui 指针，指向自动生成的 UI 类
    QTcpServer *video_server;         // 视频流 TCP 服务器
    QTcpServer *message_server;       // 按键数据 TCP 服务器
    QTextEdit *textEdit;              // 显示文本信息的控件
    QLabel *imageLabel;               // 显示图像的 QLabel
    QList<QTcpSocket *> videoClientSockets; // 存储视频流客户端套接字
    QList<QTcpSocket *> messageClientSockets; // 存储按键数据客户端套接字
    bool isSending = false;           // 是否开始发送数据
    bool key_statue = false;          // 控制是否开始按键监控
    QTimer *timer;                    // 定时器用于定期读取按键
    GamepadReader reader;            // 自定义的按键读取器
    bool stopReading;                 // 控制是否停止读取按键
    QTcpSocket *clientSocket;         // TCP 客户端连接
    bool isCapturing;
    hk::RtspCamera rtspCamera;  // 替换原来的simpleCamera
    QTimer *ir_timer;                    // 定时器用于定期读取红外图像
    QString recordStartTime;
    cv::VideoWriter camVideoWriter;  // 用于录制可见光视频
    cv::VideoWriter irVideoWriter;   // 用于录制红外视频
    QTimer *recordTimer = nullptr;  // 定时器，用于控制录制帧的频率
    cv::Mat m_currentIRFrame;     // 存储当前红外帧
    cv::Mat m_currentCamFrame;    // 存储当前可见光帧
    std::mutex m_frameMutex;      // 保护帧数据的互斥锁
    bool m_isRecordingCam;    // 添加录制状态标志
    bool m_isRecordingIR;     // 添加录制状态标志
    QByteArray m_currentImageData;  // 存储当前可见光原始数据流
    SplashScreen *splash;
    void showMainWindow();
};

#endif // MAINWINDOW_H
