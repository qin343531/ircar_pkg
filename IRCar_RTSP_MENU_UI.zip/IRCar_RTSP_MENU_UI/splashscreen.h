#ifndef SPLASHSCREEN_H
#define SPLASHSCREEN_H

#include <QWidget>
#include <QPropertyAnimation>
#include <QLabel>

class SplashScreen : public QWidget
{
    Q_OBJECT

public:
    explicit SplashScreen();
    void startAnimation();
    void setImage(const QString &imagePath);

signals:
    void animationFinished();

private:
    QLabel *imageLabel;
    QPropertyAnimation *fadeAnimation;
};

#endif // SPLASHSCREEN_H
