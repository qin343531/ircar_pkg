#include "splashscreen.h"
#include <QGraphicsOpacityEffect>
#include <QScreen>
#include <QApplication>

SplashScreen::SplashScreen()
    : QWidget(nullptr)
{
    // 设置窗口属性
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
    setAttribute(Qt::WA_TranslucentBackground);
    
    // 创建图片标签
    imageLabel = new QLabel(this);
    imageLabel->setAttribute(Qt::WA_TransparentForMouseEvents);

    // 设置动画效果
    auto effect = new QGraphicsOpacityEffect(this);
    setGraphicsEffect(effect);

    fadeAnimation = new QPropertyAnimation(effect, "opacity", this);
    fadeAnimation->setDuration(2000);
    fadeAnimation->setStartValue(1.0);
    fadeAnimation->setEndValue(0.0);
    fadeAnimation->setEasingCurve(QEasingCurve::InOutQuad);

    connect(fadeAnimation, &QPropertyAnimation::finished, [this]() {
        hide();
        emit animationFinished();
    });
}

void SplashScreen::setImage(const QString &imagePath)
{
    QScreen *screen = QApplication::primaryScreen();
    QRect screenGeometry = screen->geometry();
    
    // 设置窗口大小为全屏
    setGeometry(screenGeometry);
    
    // 加载并缩放图片
    QPixmap pixmap(imagePath);
    int height = screenGeometry.height() * 0.4;
    pixmap = pixmap.scaled(height * pixmap.width() / pixmap.height(), height,
                          Qt::KeepAspectRatio, Qt::SmoothTransformation);
    
    // 设置图片并居中
    imageLabel->setPixmap(pixmap);
    imageLabel->setGeometry(
        (screenGeometry.width() - pixmap.width()) / 2,
        (screenGeometry.height() - pixmap.height()) / 2,
        pixmap.width(),
        pixmap.height()
    );
}

void SplashScreen::startAnimation()
{
    show();
    raise();
    fadeAnimation->start(QAbstractAnimation::DeleteWhenStopped);
}
